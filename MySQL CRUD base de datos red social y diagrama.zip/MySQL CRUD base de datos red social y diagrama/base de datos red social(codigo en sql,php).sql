CREATE TABLE `Usuario` (
  `ID` int(10) UNSIGNED NOT NULL,
  `Nombre y Apellido` varchar(256) NOT NULL,
  `Correo` varchar(256) NOT NULL,
  `Contrasena` varchar(256) NOT NULL,
  `Fecha de registro` date NOT NULL,
  `Foto de perfil` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`Foto de perfil`)),
  `Descripcion` varchar(256) NOT NULL,
  `Fecha de nacimiento` date NOT NULL,
  `Genero` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `Publicacion` (
  `ID` int(10) UNSIGNED NOT NULL,
  `Usuario_ID` int(10) UNSIGNED NOT NULL,
  `Contenido` varchar(255) NOT NULL,
  `Fecha de publicacion` date NOT NULL,
  `Categoria` varchar(255) NOT NULL,
  `Privacidad` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `Comentario` (
  `ID` int(20) UNSIGNED NOT NULL,
  `Publicacion_ID` int(20) UNSIGNED NOT NULL,
  `Usuario_ID` int(20) UNSIGNED NOT NULL,
  `Contenido` varchar(255) NOT NULL,
  `Fecha de comentario` date NOT NULL,
  `Editado` tinyint(1) NOT NULL,
  `Me gusta` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `Publicacion`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Publicacion_Usuario_ID_Usuario` (`Usuario_ID`);

ALTER TABLE `Comentario`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Comentario_Usuario_ID_Usuario` (`Usuario_ID`),
  ADD KEY `Comentario_Publicacion_ID_Publicacion` (`Publicacion_ID`);

ALTER TABLE `Usuario`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `Publicacion`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `Comentario`
  MODIFY `ID` int(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `Publicacion`
  ADD CONSTRAINT `Publicacion_Usuario_ID_Usuario` FOREIGN KEY (`Usuario_ID`) REFERENCES `Publicacion` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `Comentario`
  ADD CONSTRAINT `Comentario_Publicacion_ID_Publicacion` FOREIGN KEY (`Publicacion_ID`) REFERENCES `Comentario` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `Comentario_Usuario_ID_Usuario` FOREIGN KEY (`Usuario_ID`) REFERENCES `Comentario` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;